import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import open from "open";
import clipboard from "clipboardy";
import JSON5 from "json5";

export const name = "browser-bridge";
export const inject = ["tools"];

// 默认列表：仅当 config.json5 缺失、为空或格式错误时兜底使用（与 config 的五家保持一致）
const DEFAULT_AI_LIST = [
  { id: "deepseek", name: "DeepSeek", url: "https://chat.deepseek.com" },
  { id: "kimi", name: "Kimi", url: "https://kimi.moonshot.cn" },
  { id: "doubao", name: "豆包", url: "https://www.doubao.com" },
  { id: "yuanbao", name: "元宝", url: "https://yuanbao.tencent.com" },
  { id: "qianwen", name: "千问", url: "https://www.qianwen.com/" },
];

function loadAiList() {
  // 相对插件文件自身定位，不依赖启动时的工作目录
  const configPath = path.join(
    path.dirname(fileURLToPath(import.meta.url)),
    "config.json5"
  );

  let raw;
  try {
    raw = fs.readFileSync(configPath, "utf-8");
  } catch {
    console.log("[AI Hub] 未找到 config.json5，使用默认 AI 列表（5 个）");
    return DEFAULT_AI_LIST;
  }

  try {
    const config = JSON5.parse(raw);
    const list = (Array.isArray(config?.aiList) ? config.aiList : [])
      .filter((ai) => ai && typeof ai.id === "string" && typeof ai.url === "string")
      .map((ai) => ({ id: ai.id, name: ai.name || ai.id, url: ai.url }));
    if (list.length > 0) {
      console.log(
        `[AI Hub] 已从 config.json5 加载 ${list.length} 个 AI: ${list
          .map((a) => a.name)
          .join(" / ")}`
      );
      return list;
    }
    console.log("[AI Hub] config.json5 中 aiList 为空，使用默认 AI 列表（5 个）");
  } catch (e) {
    console.log(`[AI Hub] config.json5 解析失败（${e.message}），使用默认 AI 列表（5 个）`);
  }
  return DEFAULT_AI_LIST;
}

const AI_LIST = loadAiList();

// 生成打开目标：配置了 prefillUrl（含 {prompt} 占位符）则拼参预填，否则退回普通首页
function openTarget(ai, prompt) {
  if (ai.prefillUrl && ai.prefillUrl.includes("{prompt}")) {
    return ai.prefillUrl.replace("{prompt}", encodeURIComponent(prompt));
  }
  return ai.url;
}

// 注册斜杠指令：/weballai <问题>、/webdeepseek <问题>、/webkimi <问题> ...
function registerCommands(ctx) {
  // 沙箱 ctx 上服务须经 ctx.get() 读取（官方白名单的可选查询通道，无需 inject 声明）
  const commands = typeof ctx.get === "function" ? ctx.get("commands") : ctx.commands;
  if (!commands?.register) {
    console.log("[AI Hub] 当前环境无 commands 服务，斜杠指令不可用（跳过注册）");
    return;
  }

  const safeRegister = (def) => {
    try {
      commands.register(def);
    } catch (e) {
      console.log(`[AI Hub] 指令 /${def.name} 注册失败（可能已存在）: ${e.message}`);
    }
  };

  safeRegister({
    name: "weballai",
    description: `打开所有 AI 页面（${AI_LIST.length} 个）并把问题复制到剪贴板`,
    input: { hint: "<问题>" },
    handler: async ({ rawInput }) => {
      const prompt = (rawInput || "").trim() || "你好";
      await clipboard.write(prompt);
      for (const ai of AI_LIST) {
        await open(openTarget(ai, prompt));
      }
      return {
        kind: "success",
        text: `✅ 已打开 ${AI_LIST.length} 个 AI，问题已复制到剪贴板。`,
      };
    },
  });

  for (const ai of AI_LIST) {
    safeRegister({
      name: `web${ai.id}`,
      description: `打开 ${ai.name} 页面并把问题复制到剪贴板`,
      input: { hint: "<问题>" },
      handler: async ({ rawInput }) => {
        const prompt = (rawInput || "").trim();
        await open(openTarget(ai, prompt));
        let msg = `✅ 已打开 ${ai.name}`;
        if (prompt) {
          await clipboard.write(prompt);
          msg += "，问题已复制到剪贴板。";
        }
        return { kind: "success", text: msg };
      },
    });
  }

  console.log(`[AI Hub] 斜杠指令已注册: /weballai + /web<aiId>（共 ${AI_LIST.length + 1} 个）`);
}

export function apply(ctx) {
  console.log(`[AI Hub] 插件加载成功，共 ${AI_LIST.length} 个 AI`);

  ctx.tools.register({
    name: "open_all",
    description: `一次性打开所有 AI 页面（当前 ${AI_LIST.length} 个），问题复制到剪贴板`,
    parameters: { prompt: { type: "string", description: "要问的问题" } },
    output: { schema: { type: "string" }, render: (args, value) => [{ type: "text", text: value }] },
    execute: async (args) => {
      const prompt = args?.prompt || "你好";
      await clipboard.write(prompt);
      for (const ai of AI_LIST) {
        await open(openTarget(ai, prompt));
      }
      return `✅ 已打开 ${AI_LIST.length} 个 AI，问题已复制到剪贴板。`;
    }
  });

  for (const ai of AI_LIST) {
    ctx.tools.register({
      name: `open_${ai.id}`,
      description: `单独打开 ${ai.name} 页面，问题复制到剪贴板`,
      parameters: { prompt: { type: "string", description: "要问的问题" } },
      output: { schema: { type: "string" }, render: (args, value) => [{ type: "text", text: value }] },
      execute: async (args) => {
        const prompt = args?.prompt || "";
        await open(openTarget(ai, prompt));
        let msg = `✅ 已打开 ${ai.name}`;
        if (prompt) {
          await clipboard.write(prompt);
          msg += `，问题已复制到剪贴板。`;
        }
        return msg;
      }
    });
  }

  registerCommands(ctx);
}
