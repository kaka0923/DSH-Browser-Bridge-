# dsh-browser-bridge

DeepSeek Harness（DSH）插件：一条斜杠指令，一键打开多家免费 AI 网页，问题自动复制到剪贴板——让多 AI 对比变得简单直观。

---

## 为什么做这个插件？

> "你不需要成为所有 AI 的集合，而是成为用户选择和连接 AI 的最佳入口。"

模型能力在趋同，但不同 AI 的信源、视角和表达方式差异巨大。**用同一个问题问多家 AI，就像让不同性格的专家给你出主意**：

- DeepSeek 是 **工程师** —— 逻辑严谨，擅长推理和编程
- 豆包是 **创意总监** —— 文案生动，擅长头脑风暴
- Kimi 是 **资料员** —— 超长上下文，擅长读论文和总结
- 元宝是 **生活顾问** —— 温和接地气，擅长生活场景
- 千问是 **商务专家** —— 结果导向，擅长电商和企业场景
- 智谱是 **教授** —— 知识准确，擅长学术和科普
- Minimax 是 **快枪手** —— 灵活快速，擅长多模态和轻量任务

**你的任务越复杂，越需要他们一起上阵。**

---

## 功能

- ✅ `/weballai` 一键打开全部已启用的 AI 页面
- ✅ `/web<ai>` 单独打开任意一家（如 `/webkimi`）
- ✅ 问题自动复制到剪贴板，到每个页面粘贴即可发送
- ✅ **不消耗 API** —— 打开的是各 AI 的免费 Web 端，所有对话免费进行
- ✅ 通过 `config.json5` 自定义 AI 列表，改完重启 DSH 即生效
- ✅ 本地运行，**不收集、不上传任何数据**

---

## 环境要求与登录说明

- 需要 DeepSeek Harness 桌面客户端或 Web 版
- **各 AI 站点需要使用你自己的账号登录**（微信扫码 / 手机验证码 / 账号密码均可），登录态由浏览器安全保存，一次登录长期有效
- 本插件只负责**打开页面**和**把问题复制到剪贴板**：不代理登录、不存储任何账号信息、不读取你的对话内容

---

## 安装

### 方式一：DSH 桌面客户端（推荐）

打开 DSH 客户端 → **设置 → 插件 → 安装插件** → 选择本插件目录即可。

### 方式二：CLI 安装到 web profile

```bash
dsh plugin --profile web add <插件目录>
```

### 方式三：从 npm 安装

```bash
dsh plugin --profile web add dsh-browser-bridge
```

> 安装/启用后需重启 DSH 客户端（或重载插件）生效。

---

## 使用

### 斜杠指令（最快入口）

在 DSH 输入框输入 `/` 唤起指令面板：

```
/weballai 帮我查一下xxx        ← 打开所有已启用的 AI 页面，问题进剪贴板
/webkimi 总结这篇文章          ← 只开 Kimi
/webdeepseek 帮我写xxx         ← 只开 DeepSeek
```

指令对 agent 直接执行，不产生模型消息；输入 `/web` 可看到全部可用指令。指令按 `config.json5` 中启用的 AI 自动生成。

### 自然语言 / 工具调用

也可以直接对助手说"把 xxx 同时发给所有 AI"，助手会调用 `open_all` 工具；单开某家对应 `open_deepseek` / `open_kimi` / `open_doubao` / `open_yuanbao` / `open_qianwen` 等工具。

> **提示**：打开的页面会以标签页形式追加到默认浏览器的**现有窗口**，且 Windows 不允许后台程序抢占前台焦点——留意任务栏浏览器图标的闪烁，点击即可看到新标签页。

---

## 配置：自定义 AI 列表

编辑插件根目录的 `config.json5`（UTF-8，支持注释）：

```json5
{
  aiList: [
    { id: 'deepseek', name: 'DeepSeek', url: 'https://chat.deepseek.com' },
    { id: 'kimi', name: 'Kimi', url: 'https://kimi.moonshot.cn' },
    { id: 'doubao', name: '豆包', url: 'https://www.doubao.com' },

    // ===== 以下按需启用（注释状态 = 不参与 open_all，也不生成对应工具） =====
    { id: 'yuanbao', name: '元宝', url: 'https://yuanbao.tencent.com' },
    { id: 'qianwen', name: '千问', url: 'https://www.qianwen.com/' },
    // { id: 'zhipu', name: '智谱', url: 'https://chatglm.cn' },
    // { id: 'minimax', name: 'Minimax', url: 'https://agent.minimax.cn/' },
  ]
}
```

### 配置说明

| 操作 | 方法 |
| :--- | :--- |
| **调整打开顺序** | 在数组中移动行的位置 |
| **启用某个 AI** | 删除行首的 `//` 注释符号 |
| **禁用某个 AI** | 在行首添加 `//` 注释符号 |
| **添加新 AI** | 按相同格式添加一行（`id` 用于生成指令与工具名，建议小写英文） |

> 如果 `config.json5` 缺失、`aiList` 为空或格式错误，插件会自动回退到内置的 5 个 AI 默认列表，并在启动日志中提示原因。

---

## 支持的 AI 列表

| AI | 工具 | 斜杠指令 | 状态 |
| :--- | :--- | :--- | :--- |
| DeepSeek | `open_deepseek` | `/webdeepseek` | ✅ 默认启用 |
| Kimi | `open_kimi` | `/webkimi` | ✅ 默认启用 |
| 豆包 | `open_doubao` | `/webdoubao` | ✅ 默认启用 |
| 元宝 | `open_yuanbao` | `/webyuanbao` | ✅ 默认启用 |
| 千问 | `open_qianwen` | `/webqianwen` | ✅ 默认启用 |
| 智谱 | `open_zhipu` | `/webzhipu` | 按需启用 |
| Minimax | `open_minimax` | `/webminimax` | 按需启用 |

> DeepSeek / Kimi / 豆包 / 千问 / 元宝 五家已于 2026-10 实测通过。

---

## 常见问题

**Q：我的问题会自动填进各 AI 的输入框吗？**
A：当前版本会把问题**复制到剪贴板**，你需要在各标签页手动粘贴（Ctrl+V）。自动填入在路线图中。

**Q：需要登录吗？**
A：需要。请在浏览器中用**你自己的账号**登录各 AI 页面（微信扫码、手机验证码均可），登录信息由浏览器安全存储。**本插件不代理登录、不存储任何账号信息。**

**Q：会消耗 API 费用吗？**
A：不会。插件只打开各 AI 的免费 Web 页面，不调用任何付费 API。

**Q：修改了 config.json5 为什么没生效？**
A：配置在插件加载时读取一次，修改后需重启 DSH 客户端（或重载插件）。

**Q：运行后浏览器没有弹出新窗口？**
A：这是预期行为。页面以标签页形式追加到默认浏览器的现有窗口，且 Windows 不允许后台程序抢占前台焦点——留意任务栏浏览器图标的闪烁，点击即可看到新标签页。

**Q：我的隐私安全吗？**
A：插件完全本地运行：不收集、不上传任何数据，无遥测、无埋点。唯一的副作用是**你的问题文本会被写入系统剪贴板**（用于粘贴），介意的话发送后可随意复制别的内容覆盖。

---

## 工作原理

插件是一个标准的 cordis 插件（`inject: ["tools", "commands"]`）：

- 启动时读取 `config.json5` 生成 AI 列表（缺失/损坏时回退到内置默认列表）
- 向 DSH 注册 `open_all` / `open_<ai>` 工具与 `/weballai` / `/web<ai>` 斜杠指令
- 工具被调用时：写入剪贴板（clipboardy）→ 依次打开各 AI 页面（open，走系统默认浏览器）

---

## 路线图

- ✅ V1.x：一键打开全部 AI 页面 + 剪贴板 + 斜杠指令 + 可配置 AI 列表
- 🚧 V2.0：自动填入问题 + 收集各 AI 回答 + 汇总对比
- 📋 V3.0：工作流串联，多 AI 协作完成复杂任务

---

## License

[MIT](LICENSE)
